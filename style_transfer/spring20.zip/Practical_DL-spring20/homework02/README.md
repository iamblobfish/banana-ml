The second homework consists of two assignments:
Basic track:
* `homework_part1.ipynb` - excercises in pytorch
* `homework_part2.ipynb` - training a monster convnet on Tiny Imagenet

Advanced track:
* `homework_part2.ipynb` - training a monster convnet on Tiny Imagenet
* `homework_advanced.ipynb` - more about training and inference
