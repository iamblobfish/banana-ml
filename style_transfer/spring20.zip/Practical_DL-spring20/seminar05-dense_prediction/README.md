
## Practice

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/yandexdataschool/Practical_DL/blob/spring20/seminar05-dense_prediction/seminar_dense_prediction.ipynb)

Open seminar_dense_prediction.ipynb and follow instructions from there.



